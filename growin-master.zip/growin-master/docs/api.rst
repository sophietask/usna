API
===

Growin
------

.. automodule:: growin._core
   :members:

Growth Rate
-----------

.. automodule:: growin.growth_rate
   :members:

Drifts
------

.. automodule:: growin.fourier_exb
   :members:
